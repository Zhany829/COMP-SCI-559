// @ts-check
export {};  // null statement to tell VSCode we're doing a module

// draw a picture using curves!

let canvas = document.getElementById("canvas1");
if (!(canvas instanceof HTMLCanvasElement))
    throw new Error("Canvas is not HTML Element");
var ctx = canvas.getContext("2d"); 
ctx.moveTo(20,120);  
ctx.bezierCurveTo( 20, 200, 200, 200, 200, 120 );  
ctx.bezierCurveTo( 200, 20, 380, 20, 380, 120 );  
ctx.stroke();  
