export {};  // null statement to tell VSCode we're doing a module

// draw the spiral - account for the checkbox and slider

let canvas = (document.getElementById("canvas1"));
if (!(canvas instanceof HTMLCanvasElement))
    throw new Error("Canvas is not HTML Element");

let ctx = canvas.getContext("2d");
let checkbox = /** @type {HTMLInputElement} */ (document.getElementById("checkbox"));
let slider = document.getElementById("slider");
let number = 50;
let isConnect = false;

function draw(){
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let orgX = 380; let orgY = 200;
    for (let index = 0; index < number; index++) {
        let u = (number-1-index)/(number-1);
        let x = 200 + u*180*Math.cos(2*Math.PI*4*u);
        let y = 200 + u*180*Math.sin(2*Math.PI*4*u);
        if(isConnect){
            ctx.beginPath();
            ctx.moveTo(x,y);
            ctx.lineTo(orgX, orgY);
            ctx.closePath();
            ctx.strokeStyle = "blue";
            ctx.lineWidth = 1;
            ctx.stroke();
        }else{
            ctx.beginPath();
            ctx.arc(x, y, 1.5, 0, Math.PI * 2);
            ctx.fillStyle = 'blue';
            ctx.closePath();
            ctx.fill();
        }
        orgX = x;
        orgY = y;
    }
    window.requestAnimationFrame(draw);
}
slider.onchange = function (){
    number = slider.value;
}
checkbox.onclick = function () {
    isConnect = checkbox['checked'];
}
draw();

