// @ts-check

import * as T from "../libs/CS559-Three/build/three.module.js";
import { GrWorld } from "../libs/CS559-Framework/GrWorld.js";
import { GrObject } from "../libs/CS559-Framework/GrObject.js";
import * as InputHelpers from "../libs/CS559/inputHelpers.js";

let parentOfCanvas = document.getElementById("div1");
let world = new GrWorld({ where: parentOfCanvas });


let bd2ObCtr = 0;
class GrEarth extends GrObject {
    constructor(params = {}) {
      let group = new  T.Group();

      let keyboard_geom = new T.BoxBufferGeometry(3.5,0.3,4);
      let keyboard_mat = new T.MeshStandardMaterial({color: "white", metalness: 0.5,roughness: 0.8});
      let keyboard = new T.Mesh(keyboard_geom, keyboard_mat);
      keyboard.position.y = 3.1;
      group.add(keyboard);
      
      let support_geom = new T.BoxGeometry(0.3,2.4,0.3);
      let support_mat = new T.MeshStandardMaterial({color: "black",metalness: 0.3,roughness: 0.6});
      let support = new T.Mesh(support_geom, support_mat);
      support.translateY(3.1);
      support.rotateX(Math.PI/2);
      support.translateX(-1.1);
      group.add(support);
        
      let screen_geom = new T.BoxBufferGeometry(3,0.2,4);
      let screen_mat = new T.MeshStandardMaterial({color: "white", metalness: 0.5,roughness: 0.8});
      let screen = new T.Mesh(screen_geom, screen_mat);
      screen.position.y = 3.8;
      screen.translateX(-1.3);
      screen.rotateZ(-Math.PI/2.2);
      group.add(screen);
      
      let keyboard_geometry = new T.BufferGeometry();
      const keyboard_vertices = new Float32Array( [
        //   1,0,1,    2,-1,2,    1,0,-1,   2,-1,2,    2,-1,-2,  1,0,-1,      // right
        //   -1,0,-1,  -2,-1,-2,  -1,0,1,  -2,-1,-2,  -2,-1,2,  -1,0,1,// left
          -0.59,0,-1,  -0.59,0,1,   0.59,0,-1,   -0.59,0,1,     0.59,0,1,  0.59,0,-1,	    // up
        //   -2,-1,2,  -2,-1,-2,  2,-1,2,  -2,-1,-2,  2,-1,-2,  2,-1,2,// down
        //   -1,0,1,   -2,-1,2,    1,0,1,   -2,-1,2,    2,-1,2,  1,0,1,	    // front
        //   1,0,-1,   2,-1,-2,   -1,0,-1,  2,-1,-2,   -2,-1,-2,  -1,0,-1 // back
          
      ]);
      for (let i = 0; i < keyboard_vertices.length; i++) keyboard_vertices[i] /= 2;
      keyboard_geometry.setAttribute('position',new T.BufferAttribute(keyboard_vertices,3));
      keyboard_geometry.computeVertexNormals();
      // give it UVs
      const keyboard_uvs = new Float32Array([       
          0,1,0,0,1,1,0,0,1,0,1,1
      ]);
      keyboard_geometry.setAttribute('uv',new T.BufferAttribute(keyboard_uvs,2));
      keyboard_geometry.translate(0,2.5,0);
      let keyboard_tl = new T.TextureLoader().load("./keyboard1.jpg");
      let keyboard_material = new T.MeshStandardMaterial({
          color: "white",map: keyboard_tl, lightMap : keyboard_tl});
      
      let keyboard_mesh = new T.Mesh(keyboard_geometry, keyboard_material);
      keyboard_mesh.position.y -= 1.8;
      keyboard_mesh.position.z -= -0.55;
      keyboard_mesh.scale.set(2,2,2);
      keyboard_mesh.rotateY(Math.PI/2);
      group.add(keyboard_mesh);

      let keyboard2_geometry = new T.BufferGeometry();
      const keyboard2_vertices = new Float32Array( [
        //   1,0,1,    2,-1,2,    1,0,-1,   2,-1,2,    2,-1,-2,  1,0,-1,      // right
        //   -1,0,-1,  -2,-1,-2,  -1,0,1,  -2,-1,-2,  -2,-1,2,  -1,0,1,// left
          -0.59,0,-1,  -0.59,0,1,   0.59,0,-1,   -0.59,0,1,     0.59,0,1,  0.59,0,-1,	    // up
        //   -2,-1,2,  -2,-1,-2,  2,-1,2,  -2,-1,-2,  2,-1,-2,  2,-1,2,// down
        //   -1,0,1,   -2,-1,2,    1,0,1,   -2,-1,2,    2,-1,2,  1,0,1,	    // front
        //   1,0,-1,   2,-1,-2,   -1,0,-1,  2,-1,-2,   -2,-1,-2,  -1,0,-1 // back
          
      ]);
      for (let i = 0; i < keyboard2_vertices.length; i++) keyboard2_vertices[i] /= 2;
      keyboard2_geometry.setAttribute('position',new T.BufferAttribute(keyboard2_vertices,3));
      keyboard2_geometry.computeVertexNormals();
      // give it UVs
      const keyboard2_uvs = new Float32Array([       
          0,1,0,0,1,1,0,0,1,0,1,1
      ]);
      keyboard2_geometry.setAttribute('uv',new T.BufferAttribute(keyboard2_uvs,2));
      keyboard2_geometry.translate(0,2.5,0);
      let keyboard2_tl = new T.TextureLoader().load("./keyboard2.jpg");
      let keyboard2_material = new T.MeshStandardMaterial({
          color: "white",map: keyboard2_tl});
      
      let keyboard2_mesh = new T.Mesh(keyboard2_geometry, keyboard2_material);
      keyboard2_mesh.position.y -= 1.8;
      keyboard2_mesh.position.z += -0.55;
      keyboard2_mesh.scale.set(2,2,2);
      keyboard2_mesh.rotateY(Math.PI/2);
      group.add(keyboard2_mesh);

      super(`bd2-${bd2ObCtr++}`, group);
      this.whole_ob = group;
      
      this.whole_ob.position.x = params.x ? Number(params.x) : 0;
      this.whole_ob.position.y = params.y ? Number(params.y) : 0;
      this.whole_ob.position.z = params.z ? Number(params.z) : 0;
      let scale = params.size ? Number(params.size) : 1;
      group.scale.set(scale, scale, scale);
    keyboard.scale.set(0.6,0.6,0.6);
    screen.scale.set(0.6,0.6,0.6);
      group.translateY(-3);
    }
    /**
     * StepWorld method
     * @param {*} delta 
     * @param {*} timeOfDay 
     */
    stepWorld(delta, timeOfDay) {
     
    }
  }
world.add(new GrEarth());



class GrFakeBox extends GrObject {
    constructor() {
        let group = new T.Group();
        let geometry = new T.BufferGeometry();
        const vertices = new Float32Array( [
            20,20,20,    20,-20,20,    20,20,-20,   20,-20,20,    20,-20,-20,  20,20,-20,      // right
            -20,20,-20,  -20,-20,-20,  -20,20,20,  -20,-20,-20,  -20,-20,20,  -20,20,20,// left
            -20,20,-20,  -20,20,20,   20,20,-20,   -20,20,20,     20,20,20,  20,20,-20,	    // up
            -20,-20,20,  -20,-20,-20,  20,-20,20,  -20,-20,-20,  20,-20,-20,  20,-20,20,// down
            -20,20,20,   -20,-20,20,    20,20,20,   -20,-20,20,    20,-20,20,  20,20,20,	    // front
            20,20,-20,   20,-20,-20,   -20,20,-20,  20,-20,-20,   -20,-20,-20,  -20,20,-20 // back
            
        ]);
        for (let i = 0; i < vertices.length; i++) vertices[i] *= 2;
        geometry.setAttribute('position',new T.BufferAttribute(vertices,3));
        geometry.computeVertexNormals();
        // give it UVs
        const uvs = new Float32Array( [       
            0.5,2/3,0.5,1/3,0.75,2/3,0.5,1/3,0.75,1/3,0.75,2/3,
            0.25,2/3,0.25,1/3,0,2/3,0.25,1/3,0,1/3,0,2/3,
            0.25,1,0.25,2/3,0.5,1,0.25,2/3,0.5,2/3,0.5,1,
            0.25,0,0.25,1/3,0.5,0,0.25,1/3,0.5,1/3,0.5,0,
            0.25,2/3,0.25,1/3,0.5,2/3,0.25,1/3,0.5,1/3,0.5,2/3,
            2/3,2/3,2/3,1/3,1/3,2/3,2/3,1/3,1/3,1/3,1/3,2/3
        ]);
        geometry.setAttribute('uv',new T.BufferAttribute(uvs,2));
        geometry.translate(0,2.5,0);
        let tl = new T.TextureLoader().load("./fakeSkyBox.webp");
        let material = new T.MeshStandardMaterial({
            color: "white",roughness: 0.75,map: tl, side: T.BackSide
        });
        let mesh = new T.Mesh(geometry, material);
        group.add(mesh);
        let box_geom = new T.BoxGeometry(80,80,80);
        let box_mat = new T.MeshStandardMaterial({
            color: "white"
        });
        let box = new T.Mesh(box_geom, box_mat);
        box.translateY(3);
        group.add(box);
        super("TwoTrianglesBG3", group);
    }
    }
    world.add(new GrFakeBox());

world.go();

