// @ts-check

import * as T from "../libs/CS559-Three/build/three.module.js";
import { GrWorld } from "../libs/CS559-Framework/GrWorld.js";
import { GrObject } from "../libs/CS559-Framework/GrObject.js";
import * as InputHelpers from "../libs/CS559/inputHelpers.js";

let parentOfCanvas = document.getElementById("div1");
let world = new GrWorld({ where: parentOfCanvas });


let bd2ObCtr = 0;
class GrEarth extends GrObject {
    constructor(params = {}) {
      let group = new  T.Group();

      let base_geom = new T.CylinderGeometry(1, 2, 1, 16);
      let base_mat = new T.MeshStandardMaterial({color: "white", metalness: 0.5,roughness: 0.8});
      let base = new T.Mesh(base_geom, base_mat);
      base.position.y = 3.3;
      group.add(base);
      
      let support_geom = new T.BoxGeometry(0.3,2,0.3);
      let support_mat = new T.MeshStandardMaterial({color: "black",metalness: 0.3,roughness: 0.6});
      let support = new T.Mesh(support_geom, support_mat);
      support.translateY(4);
      group.add(support);
        
      var _config = {
        radius: 1.4,
        map: new T.TextureLoader().load('./earth.jpg'),
    }
    
    var geometry = new T.SphereBufferGeometry(_config.radius, 64, 64);

    var material = new T.MeshPhongMaterial({
        color: 0xffffff,
        map: _config.map,
        
    });
    let earth = new T.Mesh(geometry, material);

      earth.position.y = 5.5;
      group.add(earth);
      
      super(`bd2-${bd2ObCtr++}`, group);
      this.whole_ob = group;
      this.earth = earth;
  
      this.whole_ob.position.x = params.x ? Number(params.x) : 0;
      this.whole_ob.position.y = params.y ? Number(params.y) : 0;
      this.whole_ob.position.z = params.z ? Number(params.z) : 0;
      let scale = params.size ? Number(params.size) : 1;
      group.scale.set(scale, scale, scale);
    //   group.scale.set(.5, .5, .5);
      base.scale.set(0.6,0.6,0.6);
      group.translateY(-3);
    }
    /**
     * StepWorld method
     * @param {*} delta 
     * @param {*} timeOfDay 
     */
    stepWorld(delta, timeOfDay) {
      this.earth.rotateY(0.01 * delta/10);
    }
  }
world.add(new GrEarth());

world.go();

