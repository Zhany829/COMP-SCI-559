// @ts-check

import * as T from "../libs/CS559-Three/build/three.module.js";
import { GrWorld } from "../libs/CS559-Framework/GrWorld.js";
import { GrObject } from "../libs/CS559-Framework/GrObject.js";
import * as InputHelpers from "../libs/CS559/inputHelpers.js";

let parentOfCanvas = document.getElementById("div1");

let world = new GrWorld({ where: parentOfCanvas, groundplane: null });
// world.groundplane = null;

let bg = new T.CubeTextureLoader()
    .load(
        [
            'Right (6).png', // right
            'Left (6).png', // left
            'Top (6).png', // top
            'Bottom (6).png', // bottom
            'Back (6).png', // back
            'Front (6).png' // front
        ]
    );
    world.scene.background = bg;


let bd2ObCtr = 0;
class GrEarth extends GrObject {
    constructor(params = {}) {
      let group = new  T.Group();
      var geometry = new T.SphereGeometry(5); 
      var material = new T.MeshPhongMaterial({
        envMap: bg, 
      });
      var mesh = new T.Mesh(geometry, material);
      
    group.add(mesh);
    var spotLight = new T.PointLight('white');
    spotLight.position.set(100000, 100000, 100000);
    // spotLight.angle = Math.PI / 2;
    // var spotLight2 = new T.AmbientLight(0xffffff);
    group.add(spotLight);
    // group.add(spotLight2)

      super(`bd2-${bd2ObCtr++}`, group);
      this.whole_ob = group;
      
      this.whole_ob.position.x = params.x ? Number(params.x) : 0;
      this.whole_ob.position.y = params.y ? Number(params.y) : 0;
      this.whole_ob.position.z = params.z ? Number(params.z) : 0;
      let scale = params.size ? Number(params.size) : 1;
      group.scale.set(scale, scale, scale);
   
      group.translateY(-3);
    }
    /**
     * StepWorld method
     * @param {*} delta 
     * @param {*} timeOfDay 
     */
    stepWorld(delta, timeOfDay) {
     
    }
  }
  world.add(new GrEarth());
// let bd2ObCtr1 = 0;
// class GrEarth1 extends GrObject {
//     constructor(params = {}) {
//       let group = new  T.Group();
//       var geometry = new T.SphereGeometry(10); 
//       var material = new T.MeshPhongMaterial({
//         envMap: bg, 
//       });
//       var mesh = new T.Mesh(geometry, material);
      
//     group.add(mesh);
//     // var spotLight = new T.SpotLight('white', 0.9);
//     // spotLight.position.set(30, 20, 20);
//     // spotLight.angle = Math.PI / 2;
//     // var spotLight2 = new T.AmbientLight(0xffffff);
//     // group.add(spotLight);
//     // group.add(spotLight2)

//       super(`bd2-${bd2ObCtr1++}`, group);
//       this.whole_ob = group;
      
//       this.whole_ob.position.x = params.x ? Number(params.x) : 0;
//       this.whole_ob.position.y = params.y ? Number(params.y) : 0;
//       this.whole_ob.position.z = params.z ? Number(params.z) : 0;
//       let scale = params.size ? Number(params.size) : 1;
//       group.scale.set(scale, scale, scale);
   
//       group.translateY(-3);
//     }
//     /**
//      * StepWorld method
//      * @param {*} delta 
//      * @param {*} timeOfDay 
//      */
//     stepWorld(delta, timeOfDay) {
     
//     }
//   }
//   world.add(new GrEarth1({y:20}));
let wallObjCnt = 0;
class GrWall2 extends GrObject {
    constructor(params = {}) {
        let group = new  T.Group();
        
        var _config = {
          radius: 10,
          map: new T.TextureLoader().load('./wall2.png'),
          
      }
      
      var geometry = new T.SphereBufferGeometry(_config.radius, 64, 64);
  
      var material = new T.MeshPhongMaterial({
          color: 0xffffff,
          map: _config.map,
          normalMap: new T.TextureLoader().load('./wallNormal2.png'),
          normalScale: new T.Vector2(1.5, 1.5),
          envMap: bg, 
      });
      let earth = new T.Mesh(geometry, material);
  
        earth.position.y = 5.5;
        group.add(earth);
        // var spotLight = new T.SpotLight('white', 0.9);
        // spotLight.position.set(-60, -60, -60);
        // spotLight.angle = Math.PI / 2;
        // var spotLight2 = new T.AmbientLight(0xffffff);
        // group.add(spotLight);
        // group.add(spotLight2)
        super(`wall-${wallObjCnt++}`, group);
        this.whole_ob = group;
        this.earth = earth;
    
        this.whole_ob.position.x = params.x ? Number(params.x) : 0;
        this.whole_ob.position.y = params.y ? Number(params.y) : 0;
        this.whole_ob.position.z = params.z ? Number(params.z) : 0;
        let scale = params.size ? Number(params.size) : 1;
        group.scale.set(scale, scale, scale);
      //   group.scale.set(.5, .5, .5);
        group.translateY(-3);
      }
      /**
       * StepWorld method
       * @param {*} delta 
       * @param {*} timeOfDay 
       */
      stepWorld(delta, timeOfDay) {
        // this.earth.rotateY(0.001 * delta/10);
      }
    }
world.add(new GrWall2({y:-30}));


let light = new T.DirectionalLight(0xffffff);
light.position.set(0, 20, -20 );
world.scene.add(light);

var spotLight = new T.PointLight('white');
        spotLight.position.set(0, -40, 0);

world.scene.add(spotLight);
world.go();

