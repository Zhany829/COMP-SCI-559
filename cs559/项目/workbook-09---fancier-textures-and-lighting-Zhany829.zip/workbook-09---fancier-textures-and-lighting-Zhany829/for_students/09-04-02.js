// @ts-check

import * as T from "../libs/CS559-Three/build/three.module.js";
import { GrWorld } from "../libs/CS559-Framework/GrWorld.js";
import { GrObject } from "../libs/CS559-Framework/GrObject.js";
import * as InputHelpers from "../libs/CS559/inputHelpers.js";

let parentOfCanvas = document.getElementById("div1");

let scene = new T.Scene();

let world = new GrWorld({ where: parentOfCanvas});
let bg = new T.CubeTextureLoader()
    .load(
        [
            'Right (6).png', // right
            'Left (6).png', // left
            'Top (6).png', // top
            'Bottom (6).png', // bottom
            'Back (6).png', // back
            'Front (6).png' // front
        ]
    );
    world.scene.background = bg;
    // let camera = new T.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    // camera.position.set(10, 0, 10);
    // camera.lookAt(new T.Vector3(0, 0, 0));

    // let renderer = new T.WebGL1Renderer();
    // renderer.render(scene, camera);



let bd2ObCtr = 0;
class GrEarth extends GrObject {
    constructor(params = {}) {
      let group = new  T.Group();

      let keyboard_geom = new T.BoxBufferGeometry(3.5,0.3,4);
      let keyboard_mat = new T.MeshStandardMaterial({color: "white", metalness: 0.5,roughness: 0.8});
      let keyboard = new T.Mesh(keyboard_geom, keyboard_mat);
      keyboard.position.y = 3.1;
      group.add(keyboard);
      
      let support_geom = new T.BoxGeometry(0.3,2.4,0.3);
      let support_mat = new T.MeshStandardMaterial({color: "black",metalness: 0.3,roughness: 0.6});
      let support = new T.Mesh(support_geom, support_mat);
      support.translateY(3.1);
      support.rotateX(Math.PI/2);
      support.translateX(-1.1);
      group.add(support);
        
      let screen_geom = new T.BoxBufferGeometry(3,0.2,4);
      let screen_mat = new T.MeshStandardMaterial({color: "white", metalness: 0.5,roughness: 0.8});
      let screen = new T.Mesh(screen_geom, screen_mat);
      screen.position.y = 3.8;
      screen.translateX(-1.3);
      screen.rotateZ(-Math.PI/2.2);
      group.add(screen);
      
      let keyboard_geometry = new T.BufferGeometry();
      const keyboard_vertices = new Float32Array( [
        //   1,0,1,    2,-1,2,    1,0,-1,   2,-1,2,    2,-1,-2,  1,0,-1,      // right
        //   -1,0,-1,  -2,-1,-2,  -1,0,1,  -2,-1,-2,  -2,-1,2,  -1,0,1,// left
          -0.59,0,-1,  -0.59,0,1,   0.59,0,-1,   -0.59,0,1,     0.59,0,1,  0.59,0,-1,	    // up
        //   -2,-1,2,  -2,-1,-2,  2,-1,2,  -2,-1,-2,  2,-1,-2,  2,-1,2,// down
        //   -1,0,1,   -2,-1,2,    1,0,1,   -2,-1,2,    2,-1,2,  1,0,1,	    // front
        //   1,0,-1,   2,-1,-2,   -1,0,-1,  2,-1,-2,   -2,-1,-2,  -1,0,-1 // back
          
      ]);
      for (let i = 0; i < keyboard_vertices.length; i++) keyboard_vertices[i] /= 2;
      keyboard_geometry.setAttribute('position',new T.BufferAttribute(keyboard_vertices,3));
      keyboard_geometry.computeVertexNormals();
      // give it UVs
      const keyboard_uvs = new Float32Array([       
          0,1,0,0,1,1,0,0,1,0,1,1
      ]);
      keyboard_geometry.setAttribute('uv',new T.BufferAttribute(keyboard_uvs,2));
      keyboard_geometry.translate(0,2.5,0);
      let keyboard_tl = new T.TextureLoader().load("./keyboard1.jpg");
      let keyboard_material = new T.MeshStandardMaterial({
          color: "white",map: keyboard_tl, lightMap : keyboard_tl});
      
      let keyboard_mesh = new T.Mesh(keyboard_geometry, keyboard_material);
      keyboard_mesh.position.y -= 1.8;
      keyboard_mesh.position.z -= -0.55;
      keyboard_mesh.scale.set(2,2,2);
      keyboard_mesh.rotateY(Math.PI/2);
      group.add(keyboard_mesh);

      let keyboard2_geometry = new T.BufferGeometry();
      const keyboard2_vertices = new Float32Array( [
        //   1,0,1,    2,-1,2,    1,0,-1,   2,-1,2,    2,-1,-2,  1,0,-1,      // right
        //   -1,0,-1,  -2,-1,-2,  -1,0,1,  -2,-1,-2,  -2,-1,2,  -1,0,1,// left
          -0.59,0,-1,  -0.59,0,1,   0.59,0,-1,   -0.59,0,1,     0.59,0,1,  0.59,0,-1,	    // up
        //   -2,-1,2,  -2,-1,-2,  2,-1,2,  -2,-1,-2,  2,-1,-2,  2,-1,2,// down
        //   -1,0,1,   -2,-1,2,    1,0,1,   -2,-1,2,    2,-1,2,  1,0,1,	    // front
        //   1,0,-1,   2,-1,-2,   -1,0,-1,  2,-1,-2,   -2,-1,-2,  -1,0,-1 // back
          
      ]);
      for (let i = 0; i < keyboard2_vertices.length; i++) keyboard2_vertices[i] /= 2;
      keyboard2_geometry.setAttribute('position',new T.BufferAttribute(keyboard2_vertices,3));
      keyboard2_geometry.computeVertexNormals();
      // give it UVs
      const keyboard2_uvs = new Float32Array([       
          0,1,0,0,1,1,0,0,1,0,1,1
      ]);
      keyboard2_geometry.setAttribute('uv',new T.BufferAttribute(keyboard2_uvs,2));
      keyboard2_geometry.translate(0,2.5,0);
      let keyboard2_tl = new T.TextureLoader().load("./keyboard2.jpg");
      let keyboard2_material = new T.MeshStandardMaterial({
          color: "white",map: keyboard2_tl});
      
      let keyboard2_mesh = new T.Mesh(keyboard2_geometry, keyboard2_material);
      keyboard2_mesh.position.y -= 1.8;
      keyboard2_mesh.position.z += -0.55;
      keyboard2_mesh.scale.set(2,2,2);
      keyboard2_mesh.rotateY(Math.PI/2);
      group.add(keyboard2_mesh);

      super(`bd2-${bd2ObCtr++}`, group);
      this.whole_ob = group;
      
      this.whole_ob.position.x = params.x ? Number(params.x) : 0;
      this.whole_ob.position.y = params.y ? Number(params.y) : 0;
      this.whole_ob.position.z = params.z ? Number(params.z) : 0;
      let scale = params.size ? Number(params.size) : 1;
      group.scale.set(scale, scale, scale);
    keyboard.scale.set(0.6,0.6,0.6);
    screen.scale.set(0.6,0.6,0.6);
      group.translateY(-3);
    }
    /**
     * StepWorld method
     * @param {*} delta 
     * @param {*} timeOfDay 
     */
    stepWorld(delta, timeOfDay) {
     
    }
  }
world.add(new GrEarth());


// let skyBoxCnt = 0;
// class GrSkyBox extends GrObject {
//     constructor(params = {}) {
//       let group = new  T.Group();

//     // let urls = [
//     // './right.jpg', // right
//     // './left.jpg', // left
//     // './top.jpg', // top
//     // './bottom.jpg', // bottom
//     // './back.jpg', // back
//     // './front.jpg' // front
//     // ];
//     // let skyboxCubemap = new T.CubeTextureLoader().load(urls);
//     // // skyboxCubemap.format = T.RGBFormat;
//     // let skyboxShader = T.ShaderLib['cube'];
//     // skyboxShader.uniforms['tCube'].value = skyboxCubemap;
//     // let skyBox = new T.Mesh(
//     // new T.BoxGeometry(10, 10, 10),
//     // new T.ShaderMaterial({
//     // fragmentShader: skyboxShader.fragmentShader,//片段着色器
//     // vertexShader: skyboxShader.vertexShader,//顶点着色器
//     // uniforms: skyboxShader.uniforms,//是所有顶点都具有相同的值的变量。 比如灯光，
    
//     // depthWrite: false,//深度测试
//     // side: T.BackSide//正反面
//     // })
//     // );
//     let scene = new T.Scene();
//     scene.background = new T.CubeTextureLoader()
//         .load(
//             [
//                 './right.jpg', // right
//                 './left.jpg', // left
//                 './top.jpg', // top
//                 './bottom.jpg', // bottom
//                 './back.jpg', // back
//                 './front.jpg' // front
//             ]
//         );


//       super(`skybox-${skyBoxCnt++}`, scene);
//     }
// }
// // world.add(new GrSkyBox());
// let scene = new T.Scene();
// scene.background = new T.CubeTextureLoader()
//     .load(
//         [
//             './right.jpg', // right
//             './left.jpg', // left
//             './top.jpg', // top
//             './bottom.jpg', // bottom
//             './back.jpg', // back
//             './front.jpg' // front
//         ]
//     );
// // WebGLBackground();
// // let world2 = new GrWorld({ where: parentOfCanvas, });

world.go();

