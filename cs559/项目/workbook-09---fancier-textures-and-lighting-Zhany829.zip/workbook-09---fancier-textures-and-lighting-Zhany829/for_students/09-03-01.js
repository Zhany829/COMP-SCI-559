// @ts-check

import * as T from "../libs/CS559-Three/build/three.module.js";
import { GrWorld } from "../libs/CS559-Framework/GrWorld.js";
import { GrObject } from "../libs/CS559-Framework/GrObject.js";
import * as InputHelpers from "../libs/CS559/inputHelpers.js";

let parentOfCanvas = document.getElementById("div1");
let world = new GrWorld({ where: parentOfCanvas });

let bd2ObCtr = 0;
class GrEarth extends GrObject {
    constructor(params = {}) {
      let group = new  T.Group();
        
      var _config = {
        radius: 1.4,
        map: new T.TextureLoader().load('./earthNormal.jpg'),
        
    }
    
    var geometry = new T.SphereBufferGeometry(_config.radius, 64, 64);

    var material = new T.MeshPhongMaterial({
        color: 0xffffff,
        map: _config.map,
        normalMap: new T.TextureLoader().load('./normalMap.jpg'),
        normalScale: new T.Vector2(1.5, 1.5),
    });
    let earth = new T.Mesh(geometry, material);

      earth.position.y = 5.5;
      group.add(earth);
      
      super(`bd2-${bd2ObCtr++}`, group);
      this.whole_ob = group;
      this.earth = earth;
  
      this.whole_ob.position.x = params.x ? Number(params.x) : 0;
      this.whole_ob.position.y = params.y ? Number(params.y) : 0;
      this.whole_ob.position.z = params.z ? Number(params.z) : 0;
      let scale = params.size ? Number(params.size) : 1;
      group.scale.set(scale, scale, scale);
    //   group.scale.set(.5, .5, .5);
      group.translateY(-3);
    }
    /**
     * StepWorld method
     * @param {*} delta 
     * @param {*} timeOfDay 
     */
    stepWorld(delta, timeOfDay) {
      this.earth.rotateY(0.001 * delta/10);
    }
  }
world.add(new GrEarth({x:0}));


let wallObjCnt = 0;
class GrWall extends GrObject {
    constructor(params = {}) {
        let group = new  T.Group();
        
        var _config = {
          radius: 1.4,
          map: new T.TextureLoader().load('./wall.png'),
          
      }
      
      var geometry = new T.SphereBufferGeometry(_config.radius, 64, 64);
  
      var material = new T.MeshPhongMaterial({
          color: 0xffffff,
          map: _config.map,
          normalMap: new T.TextureLoader().load('./wallBump.png'),
          normalScale: new T.Vector2(1.5, 1.5),
      });
      let earth = new T.Mesh(geometry, material);
  
        earth.position.y = 5.5;
        group.add(earth);
        
        super(`wall-${wallObjCnt++}`, group);
        this.whole_ob = group;
        this.earth = earth;
    
        this.whole_ob.position.x = params.x ? Number(params.x) : 0;
        this.whole_ob.position.y = params.y ? Number(params.y) : 0;
        this.whole_ob.position.z = params.z ? Number(params.z) : 0;
        let scale = params.size ? Number(params.size) : 1;
        group.scale.set(scale, scale, scale);
      //   group.scale.set(.5, .5, .5);
        group.translateY(-3);
      }
      /**
       * StepWorld method
       * @param {*} delta 
       * @param {*} timeOfDay 
       */
      stepWorld(delta, timeOfDay) {
        this.earth.rotateY(0.001 * delta/10);
      }
    }
  world.add(new GrWall({x:-3}));

  let wall2ObjCnt = 0;
class GrWall2 extends GrObject {
    constructor(params = {}) {
        let group = new  T.Group();
        
        var _config = {
          radius: 1.4,
          map: new T.TextureLoader().load('./wall2.png'),
          
      }
      
      var geometry = new T.SphereBufferGeometry(_config.radius, 64, 64);
  
      var material = new T.MeshPhongMaterial({
          color: 0xffffff,
          map: _config.map,
          normalMap: new T.TextureLoader().load('./wallNormal2.png'),
          normalScale: new T.Vector2(1.5, 1.5),
      });
      let earth = new T.Mesh(geometry, material);
  
        earth.position.y = 5.5;
        group.add(earth);
        
        super(`wall-${wallObjCnt++}`, group);
        this.whole_ob = group;
        this.earth = earth;
    
        this.whole_ob.position.x = params.x ? Number(params.x) : 0;
        this.whole_ob.position.y = params.y ? Number(params.y) : 0;
        this.whole_ob.position.z = params.z ? Number(params.z) : 0;
        let scale = params.size ? Number(params.size) : 1;
        group.scale.set(scale, scale, scale);
      //   group.scale.set(.5, .5, .5);
        group.translateY(-3);
      }
      /**
       * StepWorld method
       * @param {*} delta 
       * @param {*} timeOfDay 
       */
      stepWorld(delta, timeOfDay) {
        this.earth.rotateY(0.001 * delta/10);
      }
    }
  world.add(new GrWall2({x:3}));
world.go();

