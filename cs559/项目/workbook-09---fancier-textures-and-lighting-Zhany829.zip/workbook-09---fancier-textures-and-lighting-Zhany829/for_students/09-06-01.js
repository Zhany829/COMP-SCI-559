/*jshint esversion: 6 */
// @ts-check

import * as T from "../libs/CS559-Three/build/three.module.js";
import { GrWorld } from "../libs/CS559-Framework/GrWorld.js";
import { GrObject } from "../libs/CS559-Framework/GrObject.js";
import * as InputHelpers from "../libs/CS559/inputHelpers.js";
import * as Simple from "../libs/CS559-Framework/SimpleObjects.js";

/**
 *
 * @param {GrObject} obj
 * @param {number} [speed=1] - rotations per second
 */
function spinY(obj, speed = 1) {
  obj.stepWorld = function(delta, timeOfDay) {
    obj.objects.forEach(obj => obj.rotateY(((speed * delta) / 1000) * Math.PI));
  };
  return obj;
}

function test() {
  let parentOfCanvas = document.getElementById("div1");

  let lights = [];
  let pointLight = new T.PointLight('white', 0.5)
  // pointLight.position.x = 2
  // pointLight.position.y = 3
  // pointLight.position.z = 4
  pointLight.position.set(0,10,3);
  pointLight.castShadow = true;
 lights.push(pointLight);

 var spotLight = new T.SpotLight(0xAA7355, 0.9);
    spotLight.position.set(300, 200, 200);
    spotLight.angle = Math.PI / 2;
    var spotLight2 = new T.AmbientLight(0xffffff);
    lights.push(spotLight);
    lights.push(spotLight2)

  let world = new GrWorld({ where: parentOfCanvas });
  // world
  /**
   * Some Stuff in the world to cast and receive shadows
   */
  // a high object to cast shadows on lower objects
  let gr = new T.Group();
  let mat = new T.MeshStandardMaterial({ color: "blue" });
  let geom = new T.TorusBufferGeometry();
  let tmesh = new T.Mesh(geom, mat);
  tmesh.rotateX(Math.PI / 2);
  tmesh.scale.set(0.5, 0.5, 0.25);
  tmesh.translateX(-2);
  gr.add(tmesh);
  gr.translateY(3);
  let highobj = new GrObject("high obj", gr);
  spinY(highobj);
  world.add(highobj);

  // some low objects to be shadowed - although these
  // should cast shadows on the ground plane
  world.add(spinY(new Simple.GrCube({ x: -3, y: 1 })));
  world.add(spinY(new Simple.GrTorusKnot({ x: 3, y: 1, size: 0.5 })));

  /**
   * Turn on Shadows - this is the student's job in the assignment
   * Remember to:
   * - make a spotlight and turn on its shadows
   * - have objects (including the ground plane) cast / receive shadows
   * - turn on shadows in the renderer
   *
   * it's about 15 lines (with a recursive "loop" to enable shadows for all objects)
   * but you can also just turn things on as you make objects
   */
 
  // for (let i = 0; i < world.objects.length; i++) {
  //   for (let j = 0; j < world.objects[i].objects.length; j++) {
  //     world.objects[i].objects[j].castShadow = true;
  //     world.objects[i].objects[j].receiveShadow = true;
  //   }
  // }
   world.renderer.shadowMap.enabled = true
   world.scene.traverse(o => o.receiveShadow = true);
   world.scene.traverse(o => o.castShadow = true);
    world.groundplane.castShadow = true;
    world.groundplane.receiveShadow = true;
 
  world.go();
}
test();

