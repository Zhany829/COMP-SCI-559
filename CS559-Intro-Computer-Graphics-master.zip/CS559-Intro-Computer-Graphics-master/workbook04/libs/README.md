# Library Sub-Directory for CS559 Workbooks

This directory contains files used by CS559 workbooks. It is included in workbooks.

Students should not edit the files in this directory or add to them without explicit instructions from the course staff.

Students are welcome to read the code.

Some of the files in this directory are written by Michael Gleicher and / or Florian Heimerl for the class.

Some of the files in this directory are open source libraries provided for students to use in their assignments. These files are provided under the terms of their respective licenses. The sources of these files are:
