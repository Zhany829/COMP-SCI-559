## CS 559 copy of THREE

This is a copy of the THREE.js javascript library adapted for CS559.

The repository/directory is a copy of the THREE.js library as used in CS559. We have only included the parts relevant to class (for example, we do not include most of the examples). We have tried to keep the organization intact to the extent possible (just a few files moved around). 

The original README.md file for THREE.js is in README-THREE.md.
