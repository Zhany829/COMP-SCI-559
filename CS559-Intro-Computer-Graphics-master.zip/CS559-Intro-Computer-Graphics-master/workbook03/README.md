## README file for a workbook

A Student should fill this out! (see https://graphics.cs.wisc.edu/Courses/559-sp2020/pages/workbooks/)

- ** Name: Kunlun Wang** 
- ** GitHub ID: kunlunW** 
- ** WiscID: 907 809 8895**

### Attribution for any code you are using from someplace else:

I learned and referenced how to create a canvas color gradient from the website: 
https://developer.mozilla.org/en-US/docs/Web/API/CanvasGradient/addColorStop 

### Notes for the grader: 
