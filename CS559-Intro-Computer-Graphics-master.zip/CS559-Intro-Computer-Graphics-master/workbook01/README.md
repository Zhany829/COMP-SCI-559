## README file for a workbook

A Student should fill this out! (see https://graphics.cs.wisc.edu/Courses/559-sp2020/pages/workbooks/)

- ** Name: Kunlun Wang ** 
- ** GitHub ID: KunlunW ** 
- ** WiscID: 907 809 8895 **

### Attribution for any code you are using from someplace else:

I refered to the color to hex conversion code provided by the instruction 

website: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number/toString


### Notes for the grader: 
