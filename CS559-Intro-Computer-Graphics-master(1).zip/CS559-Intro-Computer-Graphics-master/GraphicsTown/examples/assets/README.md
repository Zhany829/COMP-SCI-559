- Race Car
	https://opengameart.org/content/lowpoly-racecar
	CC0
	converted from Blender